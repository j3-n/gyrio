// Code generated from Pkl module `gyrio.KeybindConfig`. DO NOT EDIT.
package keybinds

import "github.com/apple/pkl-go/pkl"

func init() {
	pkl.RegisterMapping("gyrio.KeybindConfig", KeybindConfig{})
}
