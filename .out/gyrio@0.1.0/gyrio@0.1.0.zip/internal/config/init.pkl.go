// Code generated from Pkl module `gyrio.AppConfig`. DO NOT EDIT.
package config

import "github.com/apple/pkl-go/pkl"

func init() {
	pkl.RegisterMapping("gyrio.AppConfig", AppConfig{})
}
