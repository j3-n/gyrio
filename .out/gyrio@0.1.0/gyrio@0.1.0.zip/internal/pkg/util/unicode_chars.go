package util

const (
	LEFT_ARROW  = '◀'
	RIGHT_ARROW = '▶'
	CROSS       = '┼'
)
