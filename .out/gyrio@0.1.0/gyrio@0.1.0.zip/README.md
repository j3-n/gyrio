# gyrio
terminal database manager 
